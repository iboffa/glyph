"""Static types, lexical scopes, return analysis and unsafe boundaries."""
import math
from .syntax import Diagnostic, Function, Record, Import
from .gui import GUI_SIGNATURES
from .stdlib import STD_SIGNATURES

SCALARS = {"i64", "f64", "bool", "str"}
BUILTINS = {"print", "len", "range", "fill", "clone", "push", "argi", "clock", "ptr", "load", "store", "offset", "f64", "i64"}
BUILTINS |= GUI_SIGNATURES.keys()
BUILTINS |= STD_SIGNATURES.keys()

def canonical_type(typ):
    return {"int": "i64", "[int]": "[i64]", "*int": "*i64"}.get(typ, typ)


class Checker:
    def __init__(self, functions):
        self.declarations = functions
        self.functions = [f for f in functions if isinstance(f, Function)]
        self.records = {}
        self.methods = {}
        self.signatures = {}
        self.inferring = set()
        self.current = None

    def environment(self, f):
        env = {name: typ for name, typ, _ in f.params}
        if f.owner and not f.static:
            env["self"] = f.owner
        return env

    def validate_type(self, typ, token):
        typ = canonical_type(typ)
        valid = typ in SCALARS | {"void"} or typ in self.records
        if typ.startswith("["):
            valid = typ[1:-1] in SCALARS or typ[1:-1] in self.records
        if typ.startswith("*"):
            valid = typ[1:] in {"i64", "f64", "bool"}
        if not valid:
            raise Diagnostic("G003", f"unknown or unsupported type {typ}", token)
        return typ

    def private_access(self, owner, private, node):
        if private and (self.current is None or self.current.owner != owner):
            self.fail("G112", f"private member of {owner} is only accessible inside its methods", node)

    def writable(self, e):
        if e.kind in {"name", "index"}:
            root = e
        elif e.kind == "field":
            self.writable(e.args[0])
            return
        else:
            self.fail("G104", "mutation requires a variable, array element or addressable field", e)
        # Arrays are shared references; mutating their elements is independent
        # of replacing a field in the enclosing value record.
        if root.kind == "name" and root.value == "self" and self.current and self.current.owner:
            if not self.current.mut and not self.current.static:
                self.fail("G112", "updating self or its value fields requires a mut method", e)

    def result_type(self, f):
        if f.result:
            return f.result
        key = (f.owner, f.name)
        if key in self.inferring:
            self.fail("G111", f"cannot infer recursive result of {f.name}; add a result type", f)
        self.inferring.add(key)
        previous, self.current = self.current, f
        try:
            f.result = self.expr(f.body[0].args[0], self.environment(f), False)
        finally:
            self.current = previous
            self.inferring.remove(key)
        return f.result

    def fail(self, code, text, node):
        raise Diagnostic(code, text, node.token)

    def same(self, actual, expected, node):
        if actual != expected:
            self.fail("G102", f"expected {expected}, found {actual}", node)

    def check(self):
        for declaration in self.declarations:
            if isinstance(declaration, Import):
                self.fail("G400", "resolve imports with glyph.modules.load_program(path)", declaration)
        for record in self.declarations:
            if not isinstance(record, Record):
                continue
            if record.name in self.records or record.name in BUILTINS | SCALARS | {"int", "void", "main", "sum", "count", "zip"}:
                self.fail("G103", f"duplicate or reserved type {record.name}", record)
            self.records[record.name] = record
        for record in self.records.values():
            if not record.fields:
                self.fail("G102", "a value record requires at least one field", record)
            names = set()
            for member in [*record.fields, *record.methods]:
                if member.name in names:
                    self.fail("G103", f"duplicate member {member.name} in {record.name}", member)
                names.add(member.name)
            for field in record.fields:
                field.typ = self.validate_type(field.typ, field.token)
                if field.typ == "void":
                    self.fail("G102", "field cannot have type void", field)
            for method in record.methods:
                self.methods[(record.name, method.name)] = method
                self.functions.append(method)
        # A direct record field embeds its value. Array fields embed only a
        # descriptor, so recursive arrays do not create infinitely sized values.
        visiting, complete = set(), set()
        def layout(name):
            if name in visiting:
                self.fail("G113", f"recursive value layout for {name}; use an array indirection", self.records[name])
            if name in complete:
                return
            visiting.add(name)
            for field in self.records[name].fields:
                if field.typ in self.records:
                    layout(field.typ)
            visiting.remove(name)
            complete.add(name)
        for name in self.records:
            layout(name)
        for f in self.functions:
            if not f.owner:
                if f.name in self.signatures or f.name in BUILTINS or f.name in self.records:
                    self.fail("G103", f"duplicate or reserved function {f.name}", f)
                self.signatures[f.name] = f
            f.result = self.validate_type(f.result, f.token) if f.result else ""
            f.params = [(n, self.validate_type(t, token), token) for n, t, token in f.params]
            seen = {"self"} if f.owner and not f.static else set()
            for name, typ, token in f.params:
                if name in seen or typ == "void":
                    raise Diagnostic("G103", "duplicate parameter or void parameter type", token)
                seen.add(name)
        main = self.signatures.get("main")
        if main is None:
            from .syntax import Token
            raise Diagnostic("G108", "program requires main>i64 or main>void", Token("", 1, 1, 1))
        if main.params or self.result_type(main) not in {"i64", "void"}:
            self.fail("G108", "main must have no parameters and return i64 or void", main)
        for f in self.functions:
            self.result_type(f)
            self.current = f
            returns = self.block(f.body, self.environment(f), f.result, False)
            if f.result != "void" and not returns:
                self.fail("G106", "not every path returns a value", f)
        self.current = None
        return self.declarations

    def block(self, body, env, result, unsafe):
        returned = False
        for s in body:
            if returned:
                self.fail("G109", "unreachable statement", s)
            if s.kind == "var":
                name, typ = s.value
                typ = self.validate_type(typ, s.token) if typ else ""
                if name in env:
                    self.fail("G103", f"variable {name} already exists; shadowing is forbidden", s)
                actual = self.expr(s.args[0], env, unsafe, typ or None)
                typ = typ or actual
                if typ == "void":
                    self.fail("G102", "variable cannot have type void", s)
                self.same(actual, typ, s.args[0])
                s.value = (name, typ)
                env[name] = typ
            elif s.kind == "set":
                target, value = s.args
                typ = self.expr(target, env, unsafe)
                self.writable(target)
                if target.kind == "index" and target.args[0].typ == "str":
                    self.fail("G104", "strings are immutable", target)
                self.same(self.expr(value, env, unsafe, typ), typ, value)
                if s.value != "=" and (typ not in {"i64", "f64"} or s.value == "%=" and typ != "i64"):
                    self.fail("G102", "compound assignment requires compatible numeric types", s)
            elif s.kind == "ret":
                typ = self.expr(s.args[0], env, unsafe, result) if s.args else "void"
                self.same(typ, result, s)
                returned = True
            elif s.kind == "expr":
                self.expr(s.args[0], env, unsafe)
                if s.args[0].kind not in {"call", "reduce", "method_call"}:
                    self.fail("G104", "expression statement must be a function call", s)
            elif s.kind in {"if", "while"}:
                self.same(self.expr(s.args[0], env, unsafe), "bool", s.args[0])
                a = self.block(s.body, env.copy(), result, unsafe)
                b = self.block(s.other, env.copy(), result, unsafe) if s.other else False
                returned = s.kind == "if" and a and b
            elif s.kind == "for":
                typ = self.expr(s.args[0], env, unsafe)
                if not typ.startswith("["):
                    self.fail("G102", "for requires an array", s.args[0])
                if s.value in env:
                    self.fail("G103", "loop variable shadows an existing variable", s)
                inner = env.copy()
                inner[s.value] = typ[1:-1]
                self.block(s.body, inner, result, unsafe)
            elif s.kind == "unsafe":
                returned = self.block(s.body, env.copy(), result, True)
        return returned

    def expr(self, e, env, unsafe, expected=None):
        k = e.kind
        if k in SCALARS:
            typ = k
            if k == "i64" and int(e.value) > 9223372036854775807:
                self.fail("G105", "integer literal exceeds i64", e)
            if k == "f64" and not math.isfinite(float(e.value)):
                self.fail("G105", "floating literal must be finite", e)
        elif k == "name":
            if e.value not in env:
                self.fail("G101", f"unknown variable {e.value}", e)
            typ = env[e.value]
        elif k == "array":
            item = expected[1:-1] if expected and expected.startswith("[") else None
            if not e.args and item is None:
                self.fail("G102", "empty array requires an expected array type", e)
            for arg in e.args:
                found = self.expr(arg, env, unsafe, item)
                if item is None:
                    item = found
                self.same(found, item, arg)
            if item not in SCALARS and item not in self.records:
                self.fail("G102", "arrays contain scalar or record values only", e)
            typ = f"[{item}]"
        elif k == "unary":
            # The minimum signed value is a single literal semantically.
            if e.value == "-" and e.args[0].kind == "i64" and int(e.args[0].value) == 9223372036854775808:
                e.kind, e.value, e.args = "i64", "-9223372036854775808", []
                typ = "i64"
            else:
                typ = self.expr(e.args[0], env, unsafe)
                if e.value == "not":
                    self.same(typ, "bool", e)
                elif typ not in {"i64", "f64"}:
                    self.fail("G102", "negation requires a number", e)
        elif k == "binary":
            a, b = [self.expr(x, env, unsafe) for x in e.args]
            self.same(b, a, e)
            if e.value in {"and", "or"}:
                self.same(a, "bool", e)
                typ = "bool"
            elif e.value in {"==", "!="}:
                if a not in SCALARS:
                    self.fail("G102", "equality requires scalar operands", e)
                typ = "bool"
            elif e.value in {"<", "<=", ">", ">="}:
                if a not in {"i64", "f64"}:
                    self.fail("G102", "ordering requires numbers", e)
                typ = "bool"
            else:
                if a not in {"i64", "f64"} or e.value == "%" and a != "i64":
                    self.fail("G102", "arithmetic requires compatible numbers", e)
                typ = a
        elif k == "index":
            base = self.expr(e.args[0], env, unsafe)
            self.same(self.expr(e.args[1], env, unsafe), "i64", e.args[1])
            if not base.startswith("["):
                self.fail("G102", "indexing requires an array", e)
            typ = base[1:-1]
        elif k == "field":
            base = self.expr(e.args[0], env, unsafe)
            record = self.records.get(base)
            field = next((f for f in record.fields if f.name == e.value), None) if record else None
            if field is None:
                self.fail("G101", f"no field {e.value} on {base}", e)
            self.private_access(base, field.private, e)
            typ = field.typ
        elif k == "method_call":
            base = e.args[0]
            static = base.kind == "name" and base.value in self.records and base.value not in env
            owner = base.value if static else self.expr(base, env, unsafe)
            method = self.methods.get((owner, e.value))
            if method is None:
                self.fail("G101", f"no method {e.value} on {owner}", e)
            if static != method.static:
                self.fail("G104", "static methods require a type; instance methods require a value", e)
            self.private_access(owner, method.private, e)
            if method.mut:
                self.writable(base)
            if len(e.args) - 1 != len(method.params):
                self.fail("G107", f"{owner}.{e.value} expects {len(method.params)} arguments", e)
            for arg, (_, param_type, _) in zip(e.args[1:], method.params):
                self.same(self.expr(arg, env, unsafe, param_type), param_type, arg)
            e.target = method
            typ = self.result_type(method)
        elif k == "fold":
            base = self.expr(e.args[0], env, unsafe)
            if base not in {"[i64]", "[f64]"}:
                self.fail("G102", "fold requires a numeric array", e)
            typ = base[1:-1]
            self.same(self.expr(e.args[1], env, unsafe), typ, e.args[1])
        elif k == "reduce":
            name, bindings, zipped = e.value
            sources = e.args[1:]
            if len(bindings) != len(sources) or zipped and len(sources) < 2:
                self.fail("G107", "zip requires at least two arrays and one binding per array", e)
            # Sources are evaluated in the enclosing scope, before any bindings.
            types = [self.expr(source, env, unsafe) for source in sources]
            inner = env.copy()
            for binding, source, array_type in zip(bindings, sources, types):
                if not array_type.startswith("["):
                    self.fail("G102", "reduction iteration requires an array", source)
                if binding.text in inner:
                    raise Diagnostic("G103", "reduction binding shadows an existing variable", binding)
                inner[binding.text] = array_type[1:-1]
            item_type = self.expr(e.args[0], inner, unsafe)
            if name == "count":
                self.same(item_type, "bool", e.args[0])
                typ = "i64"
            else:
                if item_type not in {"i64", "f64"}:
                    self.fail("G102", "sum requires numeric values", e.args[0])
                typ = item_type
        elif k == "call":
            typ = self.call(e, env, unsafe, expected)
        else:
            raise AssertionError(k)
        e.typ = typ
        return typ

    def call(self, e, env, unsafe, expected):
        name = e.value
        if name in GUI_SIGNATURES or name in STD_SIGNATURES:
            params, result = (GUI_SIGNATURES | STD_SIGNATURES)[name]
            if len(e.args) != len(params):
                self.fail("G107", f"{name} expects {len(params)} arguments", e)
            for arg, typ in zip(e.args, params):
                self.same(self.expr(arg, env, unsafe, typ), typ, arg)
            return result
        if name in self.records:
            record = self.records[name]
            self.private_access(name, any(f.private for f in record.fields), e)
            if len(e.args) != len(record.fields):
                self.fail("G107", f"{name} expects {len(record.fields)} field values", e)
            for arg, field in zip(e.args, record.fields):
                self.same(self.expr(arg, env, unsafe, field.typ), field.typ, arg)
            e.target = record
            return name
        if name in self.signatures:
            f = self.signatures[name]
            if name == "main":
                self.fail("G104", "main cannot be called", e)
            if len(e.args) != len(f.params):
                self.fail("G107", f"{name} expects {len(f.params)} arguments", e)
            for arg, (_, typ, _) in zip(e.args, f.params):
                self.same(self.expr(arg, env, unsafe, typ), typ, arg)
            return self.result_type(f)
        arity = {"print": 1, "len": 1, "range": 1, "fill": 2, "clone": 1, "push": 2,
                 "argi": 1, "clock": 0, "ptr": 1, "load": 1, "store": 2, "offset": 2, "i64": 1, "f64": 1,
                 "sum": 1, "count": 1}
        if name not in arity:
            self.fail("G101", f"unknown function {name}", e)
        if len(e.args) != arity[name]:
            self.fail("G107", f"{name} expects {arity[name]} arguments", e)
        if name in {"ptr", "load", "store", "offset"} and not unsafe:
            self.fail("G110", f"{name} requires an unsafe block", e)
        types = [self.expr(x, env, unsafe) for x in e.args]
        if name == "sum" and types[0] in {"[i64]", "[f64]"}:
            return types[0][1:-1]
        if name == "count" and types[0] == "[bool]":
            return "i64"
        if name == "print" and types[0] in SCALARS:
            return "void"
        if name == "clock":
            return "f64"
        if name in {"range", "argi"}:
            self.same(types[0], "i64", e)
            return "[i64]" if name == "range" else "i64"
        if name == "len" and (types[0].startswith("[") or types[0] == "str"):
            return "i64"
        if name == "fill" and types[0] == "i64" and (types[1] in SCALARS or types[1] in self.records):
            return f"[{types[1]}]"
        if name == "clone" and types[0].startswith("["):
            return types[0]
        if name == "push" and types[0].startswith("[") and types[0][1:-1] == types[1]:
            return types[0]
        if name == "ptr" and types[0] in {"[i64]", "[f64]", "[bool]"}:
            return "*" + types[0][1:-1]
        if name in {"load", "offset", "store"} and types[0].startswith("*"):
            if name == "load":
                return types[0][1:]
            self.same(types[1], "i64" if name == "offset" else types[0][1:], e)
            return types[0] if name == "offset" else "void"
        if name in {"i64", "f64"} and types[0] in {"i64", "f64"}:
            return name
        self.fail("G102", f"invalid argument types for {name}: {', '.join(types)}", e)


def check(functions):
    return Checker(functions).check()
