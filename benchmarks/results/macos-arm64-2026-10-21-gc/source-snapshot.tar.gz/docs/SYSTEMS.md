# Systems and text library

These typed builtins are available to ordinary Glyph programs as well as the
self-hosted compiler. They require no imports or `unsafe` blocks.

| Call | Result | Contract |
| --- | --- | --- |
| `concat(a:str, b:str)` | `str` | Allocate the concatenation. |
| `slice(s:str, start:int, end:int)` | `str` | Borrow a byte range `[start,end)`; bounds and UTF-8 character boundaries are checked. |
| `byte_at(s:str, index:int)` | `int` | Read one unsigned UTF-8 byte, with bounds checking. |
| `chr(code:int)` | `str` | Encode one Unicode scalar; reject surrogates/out-of-range values. |
| `join(parts:[str], count:int, separator:str)` | `str` | Join the first `count` entries in one allocation; reject an invalid count. |
| `str_i64(n:int)` | `str` | Decimal integer text. |
| `str_f64(n:f64)` | `str` | Number text with 17 significant digits. |
| `parse_i64(s:str)` | `int` | Parse complete decimal digits with an optional leading minus; no whitespace or leading plus. Overflow or invalid text traps. |
| `parse_f64(s:str)` | `f64` | Parse complete finite numeric text using the C numeric parser; finite underflow is allowed. |
| `valid_f64(s:str)` | `bool` | Whether the text can be parsed as a finite number. |
| `read_file(path:str)` | `str` | Read an entire seekable file as validated UTF-8. |
| `write_file(path:str, text:str)` | `void` | Create/truncate and write a file; check write/close errors. |
| `same_file(a:str, b:str)` | `bool` | True for identical path text, or existing paths referring to the same file identity. |
| `file_exists(path:str)` | `bool` | Whether the path currently names a regular file; follows symlinks, returns false for missing paths/directories. |
| `argc()` | `int` | Count arguments, excluding the executable. |
| `arg(index:int)` | `str` | Read a UTF-8 argument; index zero is the first program argument. |
| `getenv(name:str)` | `str` | Read a UTF-8 environment value; missing variables return an empty string. |
| `platform()` | `str` | `macos`, `windows`, or `posix` for other builds. |
| `process(arguments:[str])` | `int` | POSIX: execute/wait for a program; element zero names the executable. No shell parsing. |
| `eprint(text:str)` | `void` | Write text plus newline to standard error. |
| `exit(status:int)` | `void` | Exit using the low 8 bits of the status, running registered cleanup. |

`int` is the existing `i64` alias. Ordinary string lengths and `slice` offsets
count UTF-8 bytes, not characters. `slice` shares stable storage with its input.
Concatenated, formatted, joined, encoded and file-read strings belong to the same
nonmoving garbage-collected heap as arrays. Unreachable intermediate strings
can be reclaimed. Repeated concatenation still copies a quadratic number of
bytes; preallocate a parts array and use `join` for larger output. A small slice
keeps its entire backing string alive.

Strings may contain U+0000, but filesystem paths, environment names and child
process arguments reject embedded NUL. Text files and arguments must be valid
UTF-8; this API is not binary file I/O. `write_file` is a direct truncating write,
not an atomic replacement. `same_file` does not canonicalize nonexistent paths
or protect against concurrent filesystem changes.

`process` inherits standard streams and the environment, flushes parent output
before launch, and returns the child's exit code (or `128 + signal` when killed
by a signal). Launch/wait failures are runtime errors. Its initial implementation
supports POSIX systems; calling it on Windows reports an unsupported-operation
error. An argument containing spaces, quotes, `$()` or semicolons is passed as a
literal argument. Callers explicitly choosing a shell executable are responsible
for the resulting shell semantics.

New failures use `R009` for text/encoding/conversion contracts and `R010` for
filesystem/process failures. Bounds errors remain `R003`; missing arguments use
`R005`. As with existing runtime traps, these report a source location and exit
with status 70.

```gly
main>void
  output := arg(0)
  text := join(["hello", "Glyph"], 2, " ")
  write_file(output, concat(text, "\n"))
  print(read_file(output))
```
